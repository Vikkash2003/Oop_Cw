
import React, { useState } from 'react';
import axios from 'axios';

const TicketBookingPlatform = () => {
  const [totalTicket, setTotalTicket] = useState(20);
  const [vendorCount, setVendorCount] = useState(3);
  const [releaseRate, setReleaseRate] = useState(1000);
  const [customerCount, setCustomerCount] = useState(5);
  const [retrieveRate, setRetrieveRate] = useState(500);
  const [maxCapacity, setMaxCapacity] = useState(10);
  const [isStarted, setIsStarted] = useState(false);

  const handleStart = async () => {
    const config = {
      totalTickets: Number(totalTicket),
      vendorCount: Number(vendorCount),
      vendorReleaseRate: Number(releaseRate),
      customerCount: Number(customerCount),
      ticketRetrievalRate: Number(retrieveRate),
      maxPoolCapacity: Number(maxCapacity)
    };

    try {
      // Sending the config to the backend to start the system
      const response = await axios.post('http://localhost:8080/ticket-system/start', config, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      setIsStarted(true);
      console.log('Ticket booking started', response.data);
    } catch (error) {
      console.error('Error starting the system:', error);
      console.error('Error details:', error.response?.data);
    }
  };

  const handleStop = async () => {
    try {
      // Sending the request to stop the ticket system
      const response = await axios.post('http://localhost:8080/ticket-system/stop');
      setIsStarted(false);
      console.log('Ticket booking stopped', response.data);
    } catch (error) {
      console.error('Error stopping the system:', error);
      console.error('Error details:', error.response?.data);
    }
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>Rap World 2025 Ticket Booking Platform</h1>

      <div style={styles.inputContainer}>
        <label style={styles.label}>Total Ticket: {totalTicket}</label>
        <input
          type="range"
          min="1"
          max="1000"
          value={totalTicket}
          onChange={(e) => setTotalTicket(e.target.value)}
          style={styles.rangeInput}
        />
      </div>

      <div style={styles.inputContainer}>
        <label style={styles.label}>Vendor Count: {vendorCount}</label>
        <input
          type="range"
          min="1"
          max="100"
          value={vendorCount}
          onChange={(e) => setVendorCount(e.target.value)}
          style={styles.rangeInput}
        />
      </div>

      <div style={styles.inputContainer}>
        <label style={styles.label}>Release Rate: {releaseRate}</label>
        <input
          type="range"
          min="500"
          max="5000"
          value={releaseRate}
          onChange={(e) => setReleaseRate(e.target.value)}
          style={styles.rangeInput}
        />
      </div>

      <div style={styles.inputContainer}>
        <label style={styles.label}>Customer Count: {customerCount}</label>
        <input
          type="range"
          min="1"
          max="100"
          value={customerCount}
          onChange={(e) => setCustomerCount(e.target.value)}
          style={styles.rangeInput}
        />
      </div>

      <div style={styles.inputContainer}>
        <label style={styles.label}>Retrieve Rate: {retrieveRate}</label>
        <input
          type="range"
          min="500"
          max="5000"
          value={retrieveRate}
          onChange={(e) => setRetrieveRate(e.target.value)}
          style={styles.rangeInput}
        />
      </div>

      <div style={styles.inputContainer}>
        <label style={styles.label}>Max Capacity: {maxCapacity}</label>
        <input
          type="range"
          min="1"
          max="1000"
          value={maxCapacity}
          onChange={(e) => setMaxCapacity(e.target.value)}
          style={styles.rangeInput}
        />
      </div>

      <div style={styles.buttonContainer}>
        <button onClick={handleStart} style={styles.buttonStart}>
          Start
        </button>
        <button onClick={handleStop} style={styles.buttonStop}>
          Stop
        </button>
      </div>

      <p style={styles.statusText}>Status: {isStarted ? 'Started' : 'Stopped'}</p>
    </div>
  );
};

const styles = {
  container: {
    fontFamily: 'Arial, sans-serif',
    backgroundColor: '#f4f4f9',
    color: '#333',
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '20px',
  },
  heading: {
    fontSize: '2.5em',
    marginBottom: '20px',
    color: '#007BFF',
    textTransform: 'uppercase',
    letterSpacing: '2px',
  },
  inputContainer: {
    marginBottom: '20px',
    width: '80%',
  },
  label: {
    fontSize: '1.1em',
    marginBottom: '5px',
    color: '#555',
  },
  rangeInput: {
    width: '100%',
    height: '10px',
    borderRadius: '5px',
    appearance: 'none',
    backgroundColor: '#ddd',
    outline: 'none',
    transition: 'background-color 0.3s ease',
  },
  buttonContainer: {
    marginTop: '30px',
    display: 'flex',
    justifyContent: 'center',
    gap: '20px',
  },
  buttonStart: {
    padding: '12px 30px',
    fontSize: '1.2em',
    cursor: 'pointer',
    backgroundColor: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
    transition: 'background-color 0.3s ease, transform 0.3s ease',
  },
  buttonStop: {
    padding: '12px 30px',
    fontSize: '1.2em',
    cursor: 'pointer',
    backgroundColor: '#dc3545',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
    transition: 'background-color 0.3s ease, transform 0.3s ease',
  },
  statusText: {
    fontSize: '1.2em',
    marginTop: '20px',
    fontWeight: 'bold',
    color: '#007BFF',
  },
};

export default TicketBookingPlatform;